import csv
from scapy.all import *


def process_packet(packet, nxdomains):
    if packet.haslayer(DNS) and packet[DNS].qr == 1:
        dns_response = packet[DNS]
        if dns_response.rcode == 3:
            query_name = dns_response.qd.qname.decode('utf-8')
            response_time = packet.time
            nxdomains.append((query_name, response_time))


def sniff_nxdomains(pcap_file):
    nxdomains = []
    packets = rdpcap(pcap_file)
    for packet in packets:
        process_packet(packet, nxdomains)

    if nxdomains:
        for query_name, response_time in nxdomains:
            print(f"NXDomain response for query '{query_name}' at time {response_time}")
    else:
        print("No NXDomain packets found.")


def create_dest_ip_protocol_list(pcap_file):
    destination_ips = []
    protocols = []
    packets = rdpcap(pcap_file)

    for packet in packets:
        if IP in packet:
            ip_packet = packet[IP]
            destination_ip = ip_packet.dst
            protocol = ip_packet.proto

            destination_ips.append(destination_ip)
            protocols.append(protocol)

    return destination_ips, protocols


pcap_file = 'CAP.pcap'

print("Sniffing NXDomain packets:")
sniff_nxdomains(pcap_file)

print("\nCreating list of destination IPs and protocols:")
destination_ips_data, protocols_data = create_dest_ip_protocol_list(pcap_file)

# Store the collected data in a CSV file
csv_filename = 'captured_data.csv'

with open(csv_filename, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Dest_IP', 'Protocol'])

    # Write destination IPs and protocols to the CSV file
    for ip, protocol in zip(destination_ips_data, protocols_data):
        writer.writerow([ip, protocol])

print("Data saved to csv")
